<?php
session_start();

$correct_user = 'potta';
$correct_pass = 'DerHeld25'; // Ändere das später!

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === $correct_user && $password === $correct_pass) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Falscher Benutzername oder Passwort';
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Login</title>
  <link href="https://cdn.jsdelivr.net/npm/@picocss/pico@1/css/pico.min.css" rel="stylesheet" />
</head>
<body>
  <main class="container">
    <h2>🔒 Admin-Login</h2>
    <?php if (!empty($error)): ?>
      <p style="color: red;"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="post">
      <input type="text" name="username" placeholder="Benutzername" required />
      <input type="password" name="password" placeholder="Passwort" required />
      <button type="submit">Einloggen</button>
    </form>
  </main>
</body>
</html>
