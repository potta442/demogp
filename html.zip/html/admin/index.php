<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('/var/www/private/config/db.php');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("
        SELECT 
            id, username, email, stripe_id, telegram_id, 
            package_name, package_type, status, 
            pips_used, high_watermark, last_payment 
        FROM users
    ");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("❌ DB-Verbindung fehlgeschlagen: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/@picocss/pico@1.5.10/css/pico.min.css" rel="stylesheet" />
  <style>
    body {
      background: #f4f7fb;
    }
    main.container {
      background: #fff;
      border-radius: 18px;
      padding: 2.5em 2em;
      box-shadow: 0 8px 32px rgba(40,60,90,0.14);
      margin-top: 2.5em;
      margin-bottom: 2.5em;
      max-width: 1200px;
    }
    h2, h3 {
      color: #23395d;
      letter-spacing: 0.01em;
      margin-bottom: 0.4em;
    }
    table { 
      font-size: 0.97rem; 
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 18px rgba(60,60,80,0.09);
      margin-bottom: 1.5em;
      overflow-x: auto;
    }
    th {
      background: #e9eff7;
      color: #2b3758;
      font-weight: bold;
      border-bottom: 2px solid #d4d7e1;
      text-align: left;
      padding: 0.7rem 1.2rem;
    }
    td {
      padding: 0.55rem 1.1rem;
      white-space: nowrap;
      border-bottom: 1px solid #f0f1f6;
    }
    .status-badge {
      display: inline-block;
      min-width: 85px;
      font-weight: bold;
      border-radius: 8px;
      padding: 0.18em 0.75em;
      text-align: center;
      font-size: 0.98em;
      box-shadow: 0 1px 5px rgba(40,70,120,0.04);
    }
    .status-active {
      background: #c6f4d6;
      color: #16843a;
      border: 1px solid #b5e7c8;
    }
    .status-inactive {
      background: #f3f4f6;
      color: #868e96;
      border: 1px solid #e2e3e6;
    }
    .status-overdue {
      background: #ffe5c6;
      color: #b26a12;
      border: 1px solid #ffd4a3;
    }
    .scroll-container {
      overflow-x: auto;
      margin-bottom: 2em;
      width: 100%;
    }
    @media (max-width: 900px) {
      table, th, td {
        font-size: 0.90rem;
      }
      main.container {
        padding: 1em 0.3em;
      }
    }
    a[role="button"] {
      background: #23395d !important;
      color: #fff !important;
      border-radius: 9px;
      padding: 0.6em 1.3em;
      font-size: 1.07rem;
      font-weight: 600;
      letter-spacing: 0.02em;
      margin-top: 1em;
      margin-bottom: 1em;
      transition: background 0.18s;
      border: none;
      box-shadow: 0 2px 10px rgba(60,60,80,0.09);
    }
    a[role="button"]:hover {
      background: #3b5fa3 !important;
      color: #fff !important;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <main class="container">
    <hgroup>
      <h2>Admin – User Management</h2>
      <h3>Live-Datenübersicht</h3>
    </hgroup>

    <div class="scroll-container">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Stripe ID</th>
            <th>Telegram ID</th>
            <th>Package</th>
            <th>Type</th>
            <th>Status</th>
            <th>Pips Used</th>
            <th>High Watermark</th>
            <th>Last Payment</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
          <tr>
            <td><?= htmlspecialchars($user['id'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['username'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['email'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['stripe_id'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['telegram_id'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['package_name'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['package_type'] ?? '') ?></td>
            <td>
              <?php
                $status = $user['status'] ?? '';
                if ($status === 'active') {
                    echo '<span class="status-badge status-active">Aktiv</span>';
                } elseif ($status === 'inactive') {
                    echo '<span class="status-badge status-inactive">Inaktiv</span>';
                } elseif ($status === 'overdue') {
                    echo '<span class="status-badge status-overdue">Überfällig</span>';
                } else {
                    echo '<span class="status-badge">' . htmlspecialchars($status) . '</span>';
                }
              ?>
            </td>
            <td><?= htmlspecialchars($user['pips_used'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['high_watermark'] ?? '') ?></td>
            <td><?= htmlspecialchars($user['last_payment'] ?? '') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <p style="text-align:right;">
      <a href="logout.php" role="button">Logout</a>
    </p>
  </main>
</body>
</html>

